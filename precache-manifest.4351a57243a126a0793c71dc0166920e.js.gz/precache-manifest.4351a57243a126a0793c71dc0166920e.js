self.__precacheManifest = [
  {
    "revision": "9c52b9257ca5e3a7b890",
    "url": "/css/404.bace5322.css"
  },
  {
    "revision": "9c52b9257ca5e3a7b890",
    "url": "/js/404.f94fb44b.js"
  },
  {
    "revision": "a79a72faec17b26f720f",
    "url": "/css/about.8084fd5b.css"
  },
  {
    "revision": "a79a72faec17b26f720f",
    "url": "/js/about.1d559b7a.js"
  },
  {
    "revision": "4ec5bae765580240bca6",
    "url": "/css/app.d48f6508.css"
  },
  {
    "revision": "4ec5bae765580240bca6",
    "url": "/js/app.58213c6a.js"
  },
  {
    "revision": "d7e8f984354acadcf558",
    "url": "/css/career.e0610ccc.css"
  },
  {
    "revision": "d7e8f984354acadcf558",
    "url": "/js/career.71a27541.js"
  },
  {
    "revision": "07fcc4c62eb021038e64",
    "url": "/css/chunk-vendors.c3178a62.css"
  },
  {
    "revision": "07fcc4c62eb021038e64",
    "url": "/js/chunk-vendors.6591ef7e.js"
  },
  {
    "revision": "8ba3a7c745bf957464e9",
    "url": "/css/contact.c62f6e92.css"
  },
  {
    "revision": "8ba3a7c745bf957464e9",
    "url": "/js/contact.2e31dbcf.js"
  },
  {
    "revision": "3e95ebde294dbfc9ac6c",
    "url": "/css/customWebsites.098f975b.css"
  },
  {
    "revision": "3e95ebde294dbfc9ac6c",
    "url": "/js/customWebsites.71011b6e.js"
  },
  {
    "revision": "c5b44f8da77a57053fd5",
    "url": "/css/fixWebsites.87f6c2bb.css"
  },
  {
    "revision": "c5b44f8da77a57053fd5",
    "url": "/js/fixWebsites.aa3123c6.js"
  },
  {
    "revision": "faaadc2c442501d92568",
    "url": "/css/mobileServices.4faa4c1a.css"
  },
  {
    "revision": "faaadc2c442501d92568",
    "url": "/js/mobileServices.3e85a51e.js"
  },
  {
    "revision": "ba8f3376300228ed5c20",
    "url": "/css/portfolio.5372765e.css"
  },
  {
    "revision": "ba8f3376300228ed5c20",
    "url": "/js/portfolio.0084a645.js"
  },
  {
    "revision": "109dc7e558a6d1933acc",
    "url": "/css/privacy.798c0ca4.css"
  },
  {
    "revision": "109dc7e558a6d1933acc",
    "url": "/js/privacy.5a335978.js"
  },
  {
    "revision": "a382d8385c0f6d8c36a2",
    "url": "/css/securityPolicy.cc82aeda.css"
  },
  {
    "revision": "a382d8385c0f6d8c36a2",
    "url": "/js/securityPolicy.2757f2f3.js"
  },
  {
    "revision": "132a4f66ce4ca38f7778",
    "url": "/css/seoSem.58beac37.css"
  },
  {
    "revision": "132a4f66ce4ca38f7778",
    "url": "/js/seoSem.aae94884.js"
  },
  {
    "revision": "53181382fc23ba89010d",
    "url": "/css/services.83bb894b.css"
  },
  {
    "revision": "53181382fc23ba89010d",
    "url": "/js/services.8b3cfa7f.js"
  },
  {
    "revision": "7e9ed720dee1f390783b",
    "url": "/js/technologies.50979f17.js"
  },
  {
    "revision": "3ce8f0acf2287e6f8709",
    "url": "/css/termsConditions.3216e299.css"
  },
  {
    "revision": "3ce8f0acf2287e6f8709",
    "url": "/js/termsConditions.17a4ce4a.js"
  },
  {
    "revision": "e451e34e84510e00b34f",
    "url": "/css/webServices.c8ac2536.css"
  },
  {
    "revision": "e451e34e84510e00b34f",
    "url": "/js/webServices.107cf4b9.js"
  },
  {
    "revision": "348a1516e76cec7e193c",
    "url": "/css/websiteBrief.d3bfd8e9.css"
  },
  {
    "revision": "348a1516e76cec7e193c",
    "url": "/js/websiteBrief.92bae07c.js"
  },
  {
    "revision": "de884e8edbab92dfb38f389f0aead362",
    "url": "/img/s5.de884e8e.png"
  },
  {
    "revision": "d81bdf22d83bc760eac9d048e677bf96",
    "url": "/img/s4.d81bdf22.png"
  },
  {
    "revision": "ca4139cbe12c42b613f8641f61be07a7",
    "url": "/img/hammer.ca4139cb.svg"
  },
  {
    "revision": "4a37f8008959c75f619bf0a3a4e2d7a2",
    "url": "/img/owl.video.play.4a37f800.png"
  },
  {
    "revision": "9acce0944308084b5d3ca68a5535453f",
    "url": "/media/mob-intro.9acce094.mp4"
  },
  {
    "revision": "c02e3b6be13b7cd2899f5e22d979b73a",
    "url": "/img/VL-book.c02e3b6b.png"
  },
  {
    "revision": "af9d5c87434998d67fe691e669f6cdfb",
    "url": "/img/andrew.af9d5c87.jpg"
  },
  {
    "revision": "6b926d96f914624ea23e862b0f817488",
    "url": "/img/iphone-h.6b926d96.png"
  },
  {
    "revision": "06d0f711bddea171772095e608b29e5e",
    "url": "/img/webapp.06d0f711.png"
  },
  {
    "revision": "7ae10db23f1e772afc06f0b1ea3ff5db",
    "url": "/img/rocket.7ae10db2.svg"
  },
  {
    "revision": "e5b15b0fd9209f053bad18d9faf07b11",
    "url": "/img/user-interact2.e5b15b0f.png"
  },
  {
    "revision": "02418ae60c762ca0d34a18bd4a0dc7a6",
    "url": "/img/bharatiyamus-phone-2.02418ae6.jpg"
  },
  {
    "revision": "c9cbcdd22e4473cdfcea50cc172c2533",
    "url": "/img/logo-bharatiyam.c9cbcdd2.png"
  },
  {
    "revision": "d71791b3b91e69b9c2dad78e6303e67b",
    "url": "/media/studio-time-lapse.d71791b3.mp4"
  },
  {
    "revision": "133581c98c8c676d3e4a3e1a10024dce",
    "url": "/img/head.133581c9.svg"
  },
  {
    "revision": "86d9973a9dea854f3b07c1adca2e59d3",
    "url": "/img/mockup.86d9973a.jpg"
  },
  {
    "revision": "de9b56ef9100b7bb156bc07c13f50aad",
    "url": "/img/Rashtram-logo.de9b56ef.png"
  },
  {
    "revision": "12e43156b4f54e9883862aaa14126d31",
    "url": "/img/light-bulb.12e43156.png"
  },
  {
    "revision": "440c90956d5487bc6d4267d76c310145",
    "url": "/img/crashlytics.440c9095.png"
  },
  {
    "revision": "6e860ff994e8b04a432154e9c5aa1b6d",
    "url": "/img/aws.6e860ff9.png"
  },
  {
    "revision": "bd50199976046f8dbbc7213edf7d36dc",
    "url": "/media/support.bd501999.mp4"
  },
  {
    "revision": "2053d4ea359b4972212c034c271e43b1",
    "url": "/img/data-dog.2053d4ea.png"
  },
  {
    "revision": "ca7ffa4572f5545b4ccdfd5e9c1bb5a5",
    "url": "/img/google.ca7ffa45.png"
  },
  {
    "revision": "82618a50ea7928fd3c73fd02fb0ce602",
    "url": "/img/sem.82618a50.jpg"
  },
  {
    "revision": "e3b08a33c4970a6642845639e3933d3b",
    "url": "/img/rashtram_mac_.e3b08a33.png"
  },
  {
    "revision": "428ff22ec11c106cb1874ccdaf035319",
    "url": "/img/ionic2.428ff22e.png"
  },
  {
    "revision": "4f0ac02ad2ff45f724da3020591c0dbf",
    "url": "/img/sewa.4f0ac02a.png"
  },
  {
    "revision": "b3b2edcd97c6bfee108d5754aefbb0e4",
    "url": "/img/cd-icon-controller.b3b2edcd.svg"
  },
  {
    "revision": "e327160ba23d1bc7c457b63798b85a69",
    "url": "/img/contact-banner2.e327160b.jpg"
  },
  {
    "revision": "4be29905abd27e5c97c6a907247b539d",
    "url": "/media/vayu.4be29905.mp4"
  },
  {
    "revision": "c4460ccf0f61b032f024823335a796cf",
    "url": "/img/VL-Logo-2.c4460ccf.png"
  },
  {
    "revision": "578425fdd87fa687e6b9f149d40f6eb6",
    "url": "/img/seo.578425fd.png"
  },
  {
    "revision": "082796f9af07d632ed6f67ccadef465d",
    "url": "/img/VL-Logo-white.082796f9.png"
  },
  {
    "revision": "e7c41c325f758fdd761b6b9c74d798ff",
    "url": "/img/banner-1.e7c41c32.jpg"
  },
  {
    "revision": "b1323922844e1b1583ea62c0922218a2",
    "url": "/img/banner-2.b1323922.jpg"
  },
  {
    "revision": "63d19493e68ea5cc8bfde9d53f7d3ae5",
    "url": "/img/tkf-mob.63d19493.png"
  },
  {
    "revision": "e207421b09c5718dd8e0f94f3cc1e1d7",
    "url": "/media/Motionden.e207421b.mp4"
  },
  {
    "revision": "54bc0cef518504505efe6a68f38d330b",
    "url": "/media/office.54bc0cef.mp4"
  },
  {
    "revision": "7343a85bbefcbb40629f4fc59a86cd7e",
    "url": "/img/brush.7343a85b.svg"
  },
  {
    "revision": "83f512998366036d71e1c39c81f8f48f",
    "url": "/img/main-base.83f51299.png"
  },
  {
    "revision": "321f0b58a805f474ed11e8c926b7bded",
    "url": "/img/mockup21a.321f0b58.png"
  },
  {
    "revision": "b6504a76fc5093e14066ef1f5160b658",
    "url": "/img/whatwedo.b6504a76.png"
  },
  {
    "revision": "846d58b94cc5124d9e6736b0d0ef6c9b",
    "url": "/img/mobapp.846d58b9.png"
  },
  {
    "revision": "6deb044f28a39d34ff9a3720072039fd",
    "url": "/img/integrations-hero-bg.6deb044f.png"
  },
  {
    "revision": "4db04c94d475c9aafc2c810928d27fde",
    "url": "/img/pattern-bg1.4db04c94.jpg"
  },
  {
    "revision": "3052d27864fc10ae515d52d30d20872d",
    "url": "/img/dark_texture.3052d278.jpg"
  },
  {
    "revision": "c8339917adb5b2ce9078b62c3ca0772f",
    "url": "/img/Sewa_Logo.c8339917.png"
  },
  {
    "revision": "80476c338cfb413c355a581062b2633d",
    "url": "/img/workplace.80476c33.jpg"
  },
  {
    "revision": "2bb146392d1f7da2e92bb4e15bc8d07c",
    "url": "/img/mac-services.2bb14639.png"
  },
  {
    "revision": "bf3affd6454f49ac14342d2d7c3a11f3",
    "url": "/img/feature-icons.bf3affd6.png"
  },
  {
    "revision": "b3b1add3b8046ce0750ba38f49e4b644",
    "url": "/img/bg-phone.b3b1add3.png"
  },
  {
    "revision": "c7dbce70868350f0e692663e0b427b48",
    "url": "/media/Sewa.c7dbce70.mp4"
  },
  {
    "revision": "6cce748cb8d52b55920b9a150b686736",
    "url": "/img/firebase-analytics.6cce748c.png"
  },
  {
    "revision": "3c8c9736b7dd769486b45d503cb99085",
    "url": "/img/device-iphone.3c8c9736.png"
  },
  {
    "revision": "bd94ed531b8e05df9b5d64f8444f07ae",
    "url": "/img/smm-macbook.b50c7b64.bd94ed53.png"
  },
  {
    "revision": "5fb89eb7a93c67bd1346244842075a25",
    "url": "/img/iphone.5fb89eb7.png"
  },
  {
    "revision": "8cee2bd6d918ff7cf991f8e8b36ae1b6",
    "url": "/img/map.8cee2bd6.png"
  },
  {
    "revision": "6387e4f44612fef4d56eeb2f3e00b34d",
    "url": "/img/bharatiyamus-tab.6387e4f4.png"
  },
  {
    "revision": "5144199ba66df982dcd49da2752a17ce",
    "url": "/img/js.5144199b.jpg"
  },
  {
    "revision": "5392e6bc22010ae5db729880be3937cc",
    "url": "/img/cartograph.5392e6bc.png"
  },
  {
    "revision": "4e4dfb9d6cb91c6b3efe047508033676",
    "url": "/img/wp.4e4dfb9d.jpg"
  },
  {
    "revision": "3c5b5daa96e3f7e227c561b8d0b70d72",
    "url": "/media/about.3c5b5daa.mp4"
  },
  {
    "revision": "f09653dbb473bb9270a9dfba5bb9e63c",
    "url": "/media/tkf.f09653db.mp4"
  },
  {
    "revision": "fba1e8c6ebf9a4a83459e6d3addf75de",
    "url": "/media/dev-process.fba1e8c6.mp4"
  },
  {
    "revision": "7384823e5677c90afc1dad8d36235e5e",
    "url": "/media/multi-device.7384823e.mp4"
  },
  {
    "revision": "c203504dde9897920790b219eb386f3a",
    "url": "/img/grad_right_mac.c203504d.png"
  },
  {
    "revision": "11ae4aab4e626643e243641a19683fd5",
    "url": "/img/gr-logo.11ae4aab.png"
  },
  {
    "revision": "96f93e308aee97b4ea27dfe2a30b6159",
    "url": "/img/app-img5.96f93e30.png"
  },
  {
    "revision": "8d9652f280838c58400a34686f2ce052",
    "url": "/media/process-dev-circle.8d9652f2.mp4"
  },
  {
    "revision": "fb51401df629dce8f0ee874da79f95ca",
    "url": "/img/device-android.fb51401d.png"
  },
  {
    "revision": "e9b2faeb40115f2c78dd9d93411ea7a5",
    "url": "/img/kausalya_IAS_academy_home.e9b2faeb.png"
  },
  {
    "revision": "267d9692ccceef0d4b813a867c7c0d2e",
    "url": "/img/vayu_mac.267d9692.png"
  },
  {
    "revision": "63a2a8dfbbf1bd82d226db0146cb949a",
    "url": "/img/mobile-intro.63a2a8df.jpeg"
  },
  {
    "revision": "1a528c8eb8f87a56c63093feb671b2bf",
    "url": "/img/akshat.1a528c8e.jpg"
  },
  {
    "revision": "7e2bab84b4773c9ba25ae37135bdfcc9",
    "url": "/media/design-process.7e2bab84.mp4"
  },
  {
    "revision": "15c2daa3bb4ea72aca7c7f8acd771b3a",
    "url": "/media/kausalya_IAS_academy_home.15c2daa3.mp4"
  },
  {
    "revision": "fc765a3d364c583996fe5f8919772b2d",
    "url": "/img/TKF_Logo_White.fc765a3d.png"
  },
  {
    "revision": "019a34261e14bc05f99ff75b3a585a60",
    "url": "/img/kausalyaiasacademy-logo.019a3426.png"
  },
  {
    "revision": "0abb4772e4d011156d9be9da26c07e02",
    "url": "/img/TKF_Logo.0abb4772.png"
  },
  {
    "revision": "1c33a71d2d6b21a8110f8f2dff925ecd",
    "url": "/media/rashtram_video.1c33a71d.mp4"
  },
  {
    "revision": "a540b6ca4cb57f54cef26c055edcdc2b",
    "url": "/img/user-interact.a540b6ca.png"
  },
  {
    "revision": "4753968b793822cc604d37c9df144d67",
    "url": "/img/app-img3.4753968b.png"
  },
  {
    "revision": "8ea1e71a09263462ddea88770aa8c059",
    "url": "/img/app-img4.8ea1e71a.png"
  },
  {
    "revision": "ad3ebe3c844d5f5dbecde8fbfe6c3f31",
    "url": "/media/cpd-web.ad3ebe3c.mp4"
  },
  {
    "revision": "3d669c4ef3966cbe0fa7bc336b5d9fdc",
    "url": "/img/motion_den_mac.3d669c4e.png"
  },
  {
    "revision": "eaed069318589c68960c11cffdec4ab9",
    "url": "/img/bootstrap.eaed0693.png"
  },
  {
    "revision": "4227424567c5be2b483a380b8ba86963",
    "url": "/img/tab-frame.42274245.png"
  },
  {
    "revision": "818c8f0ec91c58cdfb57641a47ee9cea",
    "url": "/img/app-img.818c8f0e.png"
  },
  {
    "revision": "1c505240adbfd8bdbefd95f895239d81",
    "url": "/img/sewa_mac.1c505240.png"
  },
  {
    "revision": "2a4a40728329adcc9008ac295191277d",
    "url": "/img/mockup_.2a4a4072.png"
  },
  {
    "revision": "abcfe5c33e535fc964fc570fba68c541",
    "url": "/img/vayu_logo.abcfe5c3.png"
  },
  {
    "revision": "de9b56ef9100b7bb156bc07c13f50aad",
    "url": "/img/logo.de9b56ef.png"
  },
  {
    "revision": "716242d2162863d110d7400a582d2001",
    "url": "/img/app-img2.716242d2.png"
  },
  {
    "revision": "0ead835ef3204e73ed9efd27a8ad85f7",
    "url": "/media/colors.0ead835e.mp4"
  },
  {
    "revision": "daca094cd18187a0e3a1eda9dbabade0",
    "url": "/index.html"
  },
  {
    "revision": "b3b2edcd97c6bfee108d5754aefbb0e4",
    "url": "/img/contact/cd-icon-controller.svg"
  },
  {
    "revision": "b857b6a2124bae2f075a454212461292",
    "url": "/Icon.ico"
  },
  {
    "revision": "6152b659de9ec7c0d175b9f24b74b27f",
    "url": "/img/contact/cd-icon-location.png"
  },
  {
    "revision": "1ed25c9a2a797ca50cee6a7c7f4ef814",
    "url": "/img/contact/cd-icon-location.svg"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
];